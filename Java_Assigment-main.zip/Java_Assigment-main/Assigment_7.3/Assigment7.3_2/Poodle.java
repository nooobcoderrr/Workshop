// Poodle.java
class Poodle extends Dog {
    @Override
    void makeSound() {
        System.out.println("Poodle barks softly.");
    }
}

