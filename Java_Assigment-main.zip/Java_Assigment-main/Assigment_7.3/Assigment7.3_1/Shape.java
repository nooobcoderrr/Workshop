// Shape.java
class Shape {
    void draw() {
        System.out.println("Drawing a shape.");
    }
}
