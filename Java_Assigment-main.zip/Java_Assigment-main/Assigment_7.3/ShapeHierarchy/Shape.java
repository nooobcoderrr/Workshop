// Shape.java
class Shape {
    public double getArea() {
        return 0.0; // Default implementation for area calculation
    }
}
