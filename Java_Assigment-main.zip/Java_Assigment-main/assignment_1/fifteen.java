public class fifteen {
    
    public static void main(String[] args) {
        
        int num = -55555;

        if (num<0){
            System.out.println(num + " is Negative.");
        }
        if (num>0){
            System.out.println(num + " is Positive.");
        }
        if (num==0){
            System.out.println(num + " is Zero.");
        }
    }
}
