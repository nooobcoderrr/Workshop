public class twentyseven {
    
    public static void main(String[] args) {
        
        int p = 24000;
        int r = 10;
        int t = 5;
        int si;

        for (r=1 ; r<=10 ; r++){
            si = (p * r * t)/100;
            System.out.println("Simple interest as rate of interest is " + 1 +"% = " + si);
        }
    }
}
