public class twentyone {

    public static void main(String[] args) {
        
        int i = 0;

        for (i=0 ; i<10 ; i++){
            System.out.println("Dhyey");
        }
    }
}
