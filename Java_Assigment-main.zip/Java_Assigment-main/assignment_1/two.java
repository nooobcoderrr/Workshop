public class two {
    
    public static void main(String[] args) {
        System.out.println("World");
        System.out.print("Hello");
    }
}
