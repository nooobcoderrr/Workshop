public class five {
    
    public static void main(String[] args) {
        double pi = 3.14;
        int R = 7;

        System.out.println("Area of a circle is = " + pi * (R * R));
    }
}
