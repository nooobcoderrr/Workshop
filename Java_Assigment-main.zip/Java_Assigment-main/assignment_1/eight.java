public class eight {
    
    public static void main(String[] args) {
        int weight = 50;
        double height = 1.6;
        double BMI = weight/(height * height);

        System.out.println("BMI of person is = " + BMI);
    }
}
