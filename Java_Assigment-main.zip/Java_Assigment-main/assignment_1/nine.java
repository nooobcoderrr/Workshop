public class nine {
    public static void main(String[] args) {
        // int a = 10;
        // int b = 2;
        int num1 = 4;

        int num2 = 6;

                int i;
                int product = 0;

                for(i=0 ; i<num2 ; i++){
                    product = product + num1;
                }
                System.out.println("Product of two integer numbers is : " + product);
        
        }

    }

