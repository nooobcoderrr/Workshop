public class ArrayIterationForEach {
    public static void main(String[] args) {
        int[] array = { 5, 10, 15, 20, 25 };

        for (int element : array) {
            System.out.println(element);
        }
    }
}
