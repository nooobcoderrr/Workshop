public class IsEmptyExample {

    public static void main(String[] args) {
        String text = "";

        boolean isEmpty = text.isEmpty();
        System.out.println("Is the string empty: " + isEmpty);
    }
}
