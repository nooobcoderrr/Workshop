public class StringLengthWithLengthMethod {
    public static void main(String[] args) {
        String str = "Hello, world!";
        int length = str.length();

        System.out.println("Length: " + length);
    }
}
