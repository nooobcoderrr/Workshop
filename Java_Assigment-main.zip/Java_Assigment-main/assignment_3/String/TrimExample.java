public class TrimExample {
    public static void main(String[] args) {
        String str = "   Hello, World!   ";
        String trimmedStr = str.trim();
        System.out.println("Original string: '" + str + "'");
        System.out.println("Trimmed string: '" + trimmedStr + "'");
    }
}
