public class ConcatExample {

    public static void main(String[] args) {
        String text = "Hello, World!";
        String strToConcat = " Welcome!";

        String concatenated = text.concat(strToConcat);
        System.out.println("Concatenated string: " + concatenated);
    }
}
