public class LengthExample {

    public static void main(String[] args) {
        String text = "Hello, World!";
        
        int length = text.length();
        System.out.println("Length of the string: " + length);
    }
}
