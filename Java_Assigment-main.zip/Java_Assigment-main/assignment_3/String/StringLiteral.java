public class StringLiteral {
    public static void main(String[] args) {
        String name = "ChatGPT";
        System.out.println(name);
    }
}
