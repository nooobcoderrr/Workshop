public class ToLowerCaseExample {
    public static void main(String[] args) {
        String str = "Hello, World!";
        String lowercaseStr = str.toLowerCase();
        System.out.println("Original string: " + str);
        System.out.println("Lowercase string: " + lowercaseStr);
    }
}
