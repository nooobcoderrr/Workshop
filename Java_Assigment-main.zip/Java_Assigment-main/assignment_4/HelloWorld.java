class HelloWorld {
    static {
        System.out.println("Hello World");
        System.exit(0); // Terminate the program after printing
    }
}
