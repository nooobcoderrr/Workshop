// Shape.java
public class Shape {
    public final void draw() {
        System.out.println("Drawing a shape.");
    }
}
