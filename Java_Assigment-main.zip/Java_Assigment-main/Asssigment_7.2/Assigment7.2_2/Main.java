// Main.java
public class Main {
    public static void main(String[] args) {
        Circle circle = new Circle();

        // Calling the draw() method on the Circle object
        circle.draw(); // Output: Drawing a shape.
    }
}
