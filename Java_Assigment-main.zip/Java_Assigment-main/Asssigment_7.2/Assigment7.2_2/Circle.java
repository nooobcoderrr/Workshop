// Circle.java
public class Circle extends Shape {
    // Attempting to override the final method (results in a compilation error)
    // Uncommenting the following code will result in an error
    /*
    @Override
    public void draw() {
        System.out.println("Drawing a circle.");
    }
    */
}
