// Notification.java
public class Notification {
    // Final method in the Notification class
    public final void sendNotification(String message) {
        System.out.println("Sending a notification: " + message);
    }
}
