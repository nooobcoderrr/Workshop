// EmailNotification.java
public class EmailNotification extends Notification {
    // Attempting to override the final method (results in a compilation error)
    // Uncommenting the following code will result in an error
    /*
    @Override
    public void sendNotification(String message) {
        System.out.println("Sending an email: " + message);
    }
    */
}
