// Main.java
public class Main {
    public static void main(String[] args) {
        EmailNotification emailNotification = new EmailNotification();

        // Calling the sendNotification() method on the EmailNotification object
        emailNotification.sendNotification("Important message"); // Output: Sending a notification: Important message
    }
}
